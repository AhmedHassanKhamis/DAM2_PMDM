package com.cursoandroid.retrofitcomposeapp.views

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.cursoandroid.retrofitcomposeapp.components.MainTopBarAhmed


@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun CalculadoraView(modifier: Modifier = Modifier, navController: NavController) {



    Scaffold(
        topBar = {
////            MainTopBar(title = viewModel.state.name, showBackButton = true,) {
////                navController.popBackStack()
////            }
            MainTopBarAhmed(title = "Calculadora", showBackButton = true, onClickBackButton = {
                navController.popBackStack() }) { }
        }
    ) {

        ContentCalculadoraView(it)
    }

}

//    Text(text= id.toString(), color = Color.White)


@Composable
fun ContentCalculadoraView(pad: PaddingValues) {

    var numero1 by remember { mutableStateOf("") }
    var numero2 by remember { mutableStateOf("") }
    var total by remember { mutableStateOf(0) }
    Column(modifier = Modifier.padding(pad)) {
        OutlinedTextField(
            value = numero1,
            onValueChange = { numero1 = it },
            label = { Text(text = "Numero 1") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)

        )
        OutlinedTextField(
            value = numero2,
            onValueChange = { numero2 = it },
            label = { Text(text = "Numero 2") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedButton(onClick = {
            total = (numero1.toIntOrNull()?:0) + (numero2.toIntOrNull()?:0)
        }) {
            Text(text = "Sumar")
        }

        Text(text = "Total: $total")
    }
    
}