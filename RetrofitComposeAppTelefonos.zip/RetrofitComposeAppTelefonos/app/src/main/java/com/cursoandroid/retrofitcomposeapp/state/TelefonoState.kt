package com.cursoandroid.retrofitcomposeapp.state

data class TelefonoState(
    val id: Int = 0,
    val name: String = "",
)
