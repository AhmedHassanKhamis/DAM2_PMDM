package com.cursoandroid.retrofitcomposeapp.models

data class ListaPersonajes(
    val info: Info,
    val results: List<Result>
)