package com.cursoandroid.retrofitcomposeapp.models

data class Origin(
    val name: String,
    val url: String
)