package com.cursoandroid.retrofitcomposeapp.models

data class Location(
    val name: String,
    val url: String
)