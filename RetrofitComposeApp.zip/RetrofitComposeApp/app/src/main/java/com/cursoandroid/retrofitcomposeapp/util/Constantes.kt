package com.cursoandroid.retrofitcomposeapp.util

class Constantes {
    companion object {
        const val BASE_URL = "https://rickandmortyapi.com/api/"
        const val ENDPOINT = "character"
        const val API_KEY = "?key=43534534"
        const val COLOR_CUSTOM = 0XFF640D0D
        const val CUSTOM_GREEN = 0XFF209B14
        const val MI_TEXTO = " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla ullamcorper scelerisque magna vitae dapibus. Maecenas fermentum lectus ac consequat volutpat. Phasellus varius elementum lacus, a interdum dui efficitur in. Sed pretium enim turpis, non luctus elit cursus et. Maecenas quis ante non libero ultrices mattis. Sed quis vestibulum ante. Donec massa quam, cursus in scelerisque suscipit, faucibus non odio. Morbi vel lobortis ante. Praesent maximus feugiat leo id gravida. Nam id sem sit amet ligula lacinia sodales. Sed vestibulum erat lacus, at mollis urna interdum ut. Integer ac suscipit sem.\n" +
                "\n" +
                "Fusce sed tortor volutpat ex hendrerit placerat id sed dui. Sed sagittis fermentum diam at finibus. Nullam in mattis tortor. Praesent iaculis erat mi, nec mollis risus ornare non. Sed sagittis, ligula tincidunt tincidunt gravida, massa quam tincidunt lacus, et porttitor ligula elit in lacus. Nam sed ornare quam, dictum sagittis mi. Suspendisse cursus mi eget turpis pulvinar finibus. Vivamus pulvinar sed libero non congue. Pellentesque eleifend elementum felis, eu porttitor dui rhoncus vel. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras vulputate quis ligula non iaculis.\n" +
                "\n" +
                "Donec dapibus tortor orci, a dictum quam tempus et. Aenean tempor scelerisque neque quis convallis. Mauris ut felis sit amet ante viverra lobortis ut et mauris. Nulla vitae pharetra lectus. Integer a maximus arcu. Nullam quam mauris, pretium at cursus vitae, finibus at lorem. Integer eu nibh at sem interdum gravida. Morbi vel sapien suscipit, laoreet nulla eget, consectetur enim. Cras eleifend nulla id posuere malesuada. Ut turpis ante, vehicula et velit ut, consequat dignissim felis. Integer nunc purus, ullamcorper sed quam a, blandit gravida turpis. Sed ullamcorper felis id felis faucibus, sed placerat turpis congue. Suspendisse potenti. In ac tortor sed lorem tincidunt finibus et eget sem. Sed bibendum mattis interdum. Interdum et malesuada fames ac ante ipsum primis in faucibus. "


    }
}

// https://api.raw.io/api/?key=

// https://rickandmortyapi.com/api/character


//{
//    "info": {
//    "count": 826,
//    "pages": 42,
//    "next": "https://rickandmortyapi.com/api/character/?page=2",
//    "prev": null
//},
//    "results": [
//    // ...
//    ]
//}

//"results": [
//{
//    "id": 361,
//    "name": "Toxic Rick",
//    "status": "Dead",
//    "species": "Humanoid",
//    "type": "Rick's Toxic Side",
//    "gender": "Male",
//    "origin": {
//    "name": "Alien Spa",
//    "url": "https://rickandmortyapi.com/api/location/64"
//},
//    "location": {
//    "name": "Earth",
//    "url": "https://rickandmortyapi.com/api/location/20"
//},
//    "image": "https://rickandmortyapi.com/api/character/avatar/361.jpeg",
//    "episode": [
//    "https://rickandmortyapi.com/api/episode/27"
//    ],
//    "url": "https://rickandmortyapi.com/api/character/361",
//    "created": "2018-01-10T18:20:41.703Z"
//},