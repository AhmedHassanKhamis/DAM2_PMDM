package com.example.practicarecyclerview

class UsuariosProvider {
    companion object{
        val usuarios = listOf<Usuario>(
            Usuario("Brian", "Green", "briangreen@hotmail.com","https://randomuser.me/api/portraits/men/75.jpg"),
            Usuario("Ana María", "Mariscal", "anamaria@hotmail.com","https://randomuser.me/api/portraits/women/32.jpg"),
            Usuario("Bernardo", "De la Hoz", "bernardodelh@hotmail.com","https://randomuser.me/api/portraits/men/74.jpg"),
            Usuario("Paula", "Quevedo-Salcedo", "paulaqs@hotmail.com","https://randomuser.me/api/portraits/women/76.jpg"),
            Usuario("Rediberto", "Montañés", "rediberto@hotmail.com","https://randomuser.me/api/portraits/men/69.jpg"),
            Usuario("Daniel", "Obregón", "danielob@hotmail.com","https://randomuser.me/api/portraits/men/75.jpg"),
            Usuario("Josefa", "Granada", "josefagranada@hotmail.com","https://randomuser.me/api/portraits/women/60.jpg"),
            Usuario("José María", "Del Olmo", "josemaria@hotmail.com","https://randomuser.me/api/portraits/men/60.jpg"),
            Usuario("Ahmed", "Hassan", "invent@invent.invt","https://randomuser.me/api/portraits/men/60.jpg")
            )
    }
}