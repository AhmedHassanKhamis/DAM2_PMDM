package com.example.practicarecyclerview

data class Usuario(val nombre: String, val apellido: String, val email: String,val foto: String)