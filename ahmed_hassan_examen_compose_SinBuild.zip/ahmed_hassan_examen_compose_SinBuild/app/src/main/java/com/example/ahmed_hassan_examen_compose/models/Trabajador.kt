package com.example.ahmed_hassan_examen_compose.models

class Trabajador {

}