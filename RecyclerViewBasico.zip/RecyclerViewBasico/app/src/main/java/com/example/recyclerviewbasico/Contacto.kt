package com.example.recyclerviewbasico

data class Contacto(val nombre: String, val telefono: String)