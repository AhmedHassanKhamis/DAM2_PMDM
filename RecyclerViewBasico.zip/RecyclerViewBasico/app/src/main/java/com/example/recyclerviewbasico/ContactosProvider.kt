package com.example.recyclerviewbasico

class ContactosProvider {
    companion object {
        val contactos =  listOf<Contacto>(
            Contacto("David Fernández", "654983845"),
            Contacto("María Gutiérrez", "78536412"),
            Contacto("Sergio García", "67823159"),
            Contacto("Manolo Tena", "654983845"),
            Contacto("Adelaida Montes", "917853245"),
            Contacto("Gabriela San José", "78325648"),
            Contacto("Gustavo Tellado", "689321584"),
            Contacto("Alvaro Alfaro", "7892465"),
            Contacto("Ana De Gea", "678325488"),
            Contacto("Manolo Tena", "654983845"),
            Contacto("Adelaida Montes", "917853245"),
            Contacto("Gabriela San José", "78325648"),
            Contacto("Gustavo Tellado", "689321584"),
            Contacto("Alvaro Alfaro", "7892465"),
            Contacto("Ana De Gea", "678325488"),
            Contacto("Ahmed Hassan", "678325488")

        )
    }
}