package com.example.examen_ahmed_primeraev
//DEFINICION DE MI CLASE O OBJETOS
data class SuperHero(
    val superhero: String,
    val publisher: String,
    val realName: String,
    val photo: String
)